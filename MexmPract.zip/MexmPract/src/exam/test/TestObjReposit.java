package exam.test;

import org.testng.annotations.Test;

public class TestObjReposit {
  @Test
  public void f() {
  }
}
