package exam.files;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class Pagefact 
{
	
	
	 @FindBy(id="txtUserName")
	 @CacheLookup
	 WebElement uname;
	 
	
	 
	 @FindBy(id="txtPassword")
	 @CacheLookup
	 WebElement pass;
	 
	 @FindBy(xpath="//*[@id='txtConfPassword']")
	 @CacheLookup
	 WebElement conpass;
	 
	 @FindBy(css="#DOB")
	 @CacheLookup
	 WebElement dob;
	 
	
	 @FindBy(how=How.NAME,using="txtLN")
	 @CacheLookup
	 WebElement ln;
	 
	 @FindBy(how=How.NAME,using="txtFN")
	 @CacheLookup
	 WebElement fn;

	private WebDriver driver;
	
	
	public void setUname(String uname)
	{
		(this.uname).sendKeys(uname);
	}
	
	
	public void setPassword(String pass)
	{
		(this.pass).sendKeys(pass);
	}
	
	public void setConfirmPassword(String conpass)
	{
		(this.conpass).sendKeys(conpass);
	}
	
	public void setDob(String dob)
	{
		(this.dob).sendKeys(dob);
	}
	
	public void setFn(String fn) 
	{
		(this.fn).sendKeys(fn);
	}
	
	public void setLn(String ln) 
	{
		(this.ln).sendKeys(ln);
	}

	public WebElement getPass() {
		return pass;
	}

	public WebElement getConpass() {
		return conpass;
	}

	public WebElement getDob() {
		return dob;
	}

	public WebElement getFn() {
		return fn;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getUname() {
		return uname;
	}

	public WebElement getLn() {
		return ln;
	}

	public Pagefact(WebDriver driver) {
		super();
		this.driver = driver;
	}

	

}
