package exam.test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import exam.files.Pagefact;


public class PagefactTest 

{
	static WebDriver driver=new FirefoxDriver();
	
	@Test
	public void verifyPageFactorywe ()
	{
	
		driver.get("file:///D:/Users/ADM-IG-HWDLAB1B/Desktop/SELENIUM/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		
	 String actualtitle=driver.getTitle();
	 String expectedtitle="Email Registration Form";
		
	 	 if(actualtitle.contentEquals(expectedtitle))
		{
			System.out.println("content matches");
		}
		else
		{
			System.out.println("content doesn't matches");
		}
	}
	
	@Test
	public void verifyPageFactory () throws InterruptedException
	{
		

		
		Pagefact lp = PageFactory.initElements(driver,Pagefact.class);
		
		lp.setUname("vivian");
		 driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		lp.setPassword("vivian");
		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		lp.setConfirmPassword("vivian");
		lp.setDob("11/11/11");
		Thread.sleep(2000);
		lp.setFn("vivian");
			lp.setLn("dsena");
	}
	

	
}
